#pragma once

#include "stm32f4xx_hal.h"
uint32_t microsISR(void);
void cycleCounterInit(void);
