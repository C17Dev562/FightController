#pragma once

#include "main.h"

extern I2C_HandleTypeDef hi2c1;
void MX_I2C1_Init(void);

